
USE course_db;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `course_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `binome`
--

CREATE TABLE IF NOT EXISTS `binome` (
  `idInviteur` varchar(20) NOT NULL,
  `idRecevoir` varchar(20) NOT NULL,
  PRIMARY KEY (`idInviteur`,`idRecevoir`),
  KEY `FK_idRecevoir` (`idRecevoir`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `bookmark`
--

CREATE TABLE IF NOT EXISTS `bookmark` (
  `user_id` varchar(20) NOT NULL,
  `playlist_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `chat_messages`
--

CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` varchar(20) NOT NULL,
  `receiver_id` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` varchar(20) NOT NULL,
  `content_id` varchar(20) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `comments`
--

INSERT INTO `comments` (`id`, `content_id`, `user_id`, `tutor_id`, `comment`, `date`) VALUES
('GgKI27GaA9QCCOG8hOej', 'ycxbxCPQqDc3LRgggXmj', 'Hafd59EtFN0MDyCBMouc', 'BdHr6MrbzBKO3NixBL2M', 'Yo this PFE is dope â¤ï¸', '0000-00-00');

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` int(10) NOT NULL,
  `message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` varchar(20) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `playlist_id` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `video` varchar(100) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'deactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `content`
--

INSERT INTO `content` (`id`, `tutor_id`, `playlist_id`, `title`, `description`, `video`, `thumb`, `date`, `status`) VALUES
('ycxbxCPQqDc3LRgggXmj', 'BdHr6MrbzBKO3NixBL2M', 'i9o3EILdWwbqtMJC4REp', 'advice pfe', 'sd', 'r0WYU1KV1HC3ISRMUXKP.mp4', '2Kj5lMWS2KZgv5gPf7Qk.jpg', '0000-00-00', 'active');

-- --------------------------------------------------------

--
-- Structure de la table `encadrant`
--

CREATE TABLE IF NOT EXISTS `encadrant` (
  `id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `profession` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `encadrant`
--

INSERT INTO `encadrant` (`id`, `name`, `profession`, `email`, `password`, `image`) VALUES
('40Ppe5t5das8suRC5MbP', 'salah', 'teacher', 'salah@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '1sKKQbc2BHNVz0aFcorc.jpeg'),
('BdHr6MrbzBKO3NixBL2M', 'ziedkm', 'teacher', 'zied@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'K7NGAt3CMlO26ru3lVFh.jpg'),
('T2BOaPVQ5CgrBjAj32O8', 'raja', 'journalist', 'raja@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'fNwSoMi7djWEjiokzlNN.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE IF NOT EXISTS `etudiant` (
  `id` varchar(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `idPfe` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_idPfe` (`idPfe`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `etudiant`
--

INSERT INTO `etudiant` (`id`, `name`, `email`, `password`, `image`, `idPfe`) VALUES
('Hafd59EtFN0MDyCBMouc', 'zied', 'zz@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'tTvWoJvy0Ghr58bLZOJf.jpg', 1);

-- --------------------------------------------------------

--
-- Structure de la table `likes`
--

CREATE TABLE IF NOT EXISTS `likes` (
  `user_id` varchar(20) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `content_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `likes`
--

INSERT INTO `likes` (`user_id`, `tutor_id`, `content_id`) VALUES
('Hafd59EtFN0MDyCBMouc', 'BdHr6MrbzBKO3NixBL2M', 'ycxbxCPQqDc3LRgggXmj');

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id_m` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `msg` int(255) NOT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_m`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `pfe`
--

CREATE TABLE IF NOT EXISTS `pfe` (
  `id` varchar(20) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'deactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `pfe`
--

INSERT INTO `pfe` (`id`, `tutor_id`, `title`, `description`, `thumb`, `date`, `status`) VALUES
('dORZKiHFSsHChWAMAm0d', 'BdHr6MrbzBKO3NixBL2M', 'ddd', 'qsdqs', 'lgzSRvQJ7k4fiTeqFtJo.jpg', '0000-00-00', 'In progress'),
('i9o3EILdWwbqtMJC4REp', 'BdHr6MrbzBKO3NixBL2M', 'Pfe de service', 'pfe', 'iqsnua53ZmkBgBlKgU8a.jpg', '0000-00-00', 'Done');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
