<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

$select_likes = $conn->prepare("SELECT * FROM `likes` WHERE user_id = ?");
$select_likes->execute([$user_id]);
$total_likes = $select_likes->rowCount();

$select_comments = $conn->prepare("SELECT * FROM `comments` WHERE user_id = ?");
$select_comments->execute([$user_id]);
$total_comments = $select_comments->rowCount();

$select_bookmark = $conn->prepare("SELECT * FROM `bookmark` WHERE user_id = ?");
$select_bookmark->execute([$user_id]);
$total_bookmarked = $select_bookmark->rowCount();

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <style>
       /* Progress Bar Styles */
       .progress-container {
           width: 100%;
           background-color: #e0e0e0;
           border-radius: 25px;
           overflow: hidden;
           font-size: 20px;
           
           margin-bottom: 20px;
           position: relative;
       }
       .buttonsprog button{
         background-color: #2e91c6;
         color: #e0e0e0;
         padding: 10px;
         border-radius: 5px;
         
         margin-left: 170px;
         transition-duration: 200ms;
       }
       .buttonsprog button:hover{
         background-color: #e0e0e0;
         color: black;
         cursor: pointer;
       }

       .progress-bar {
           height: 30px;
           width: 0;
           transition: width 0.5s ease;
       }

       .progress-bar.in-progress {
           background-color: #2e91c6; /* Blue for in-progress */
       } 

       .progress-bar.done {
           background-color: #28a745; /* Green for done */
       }

       .progress-bar.canceled {
           background-color: #dc3545; /* Red for canceled */
       }

       .status-text {
           position: absolute;
           width: 100%;
           text-align: center;
           top: 0;
           line-height: 30px; /* Center text vertically */
           color: black;
           font-weight: bold;
       }
   </style>

</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- quick select section starts  -->
 

<section class="quick-select">

   <h1 class="heading">quick options</h1>

   <div class="box-container">

      <?php
         if($user_id != ''){
      ?>
      <div class="box">
         <div class="progress-container">
            <div class="progress-bar" id="progress-bar" data-status="in-progress"></div>
            <div class="status-text" id="status-text">Not started</div>
         </div>
         <div class="buttonsprog">
         <button onclick="updateProgress('In progress')">Mark as in progress</button>
         <button onclick="updateProgress('done')">Mark as Done</button>
         <button onclick="updateProgress('canceled')">Mark as Canceled</button>
         </div>
      </div>
      
      
      <?php
         }else{ 
      ?>
      <div class="box" style="text-align: center;">
         <h3 class="title">login or register as a Student</h3>
          <div class="flex-btn" style="padding-top: .5rem;">
            <a href="login.php" class="option-btn">login</a>
            <a href="register.php" class="option-btn">register</a>
         </div>
      </div>
      <?php
      }
      ?>

      <?php
         if($user_id != ''){
      ?>
      <?php
         }else{ 
      ?>
      <div class="box tutor">
         <h3 class="title">Login or Register as a superviser</h3>
         <p></p>
         <a href="admin/register.php" class="inline-btn">register</a>
         <a href="admin/login.php" class="inline-btn">Login</a>
      </div>
      <?php
      }
      ?>
   </div>

</section>

<!-- quick select section ends -->

<!-- courses section starts  -->

<section class="courses">

   <h1 class="heading">Pfes</h1>

   <div class="box-container">

      <?php
         $select_courses = $conn->prepare("SELECT * FROM `pfe` ORDER BY date DESC LIMIT 6");
         $select_courses->execute();
         if($select_courses->rowCount() > 0){
            while($fetch_course = $select_courses->fetch(PDO::FETCH_ASSOC)){
               $course_id = $fetch_course['id'];

               $select_tutor = $conn->prepare("SELECT * FROM `encadrant` WHERE id = ?");
               $select_tutor->execute([$fetch_course['tutor_id']]);
               $fetch_tutor = $select_tutor->fetch(PDO::FETCH_ASSOC);
      ?>
      <div class="box">
         <div class="tutor">
            <img src="uploaded_files/<?= $fetch_tutor['image']; ?>" alt="">
            <div>
               <h3><?= $fetch_tutor['name']; ?></h3>
               <span><?= $fetch_course['date']; ?></span>
            </div>
         </div>
         <img src="uploaded_files/<?= $fetch_course['thumb']; ?>" class="thumb" alt="">
         <h3 class="title"><?= $fetch_course['title']; ?></h3>
         <a href="playlist.php?get_id=<?= $course_id; ?>" class="inline-btn">view PFE</a>
      </div>
      
      
      <?php
         }
      }else{
         echo '<p class="empty">no courses added yet!</p>';
      }
      ?>

   </div>

   <div class="more-btn">
      <a href="courses.php" class="inline-option-btn">view more</a>
   </div>

</section>

<!-- courses section ends -->

<script>
    function updateProgress(status) {
        const progressBar = document.getElementById('progress-bar');
        const statusText = document.getElementById('status-text');

        if (status === 'done') {
            progressBar.style.width = '100%';
            progressBar.className = 'progress-bar done';
            statusText.textContent = 'Done';
        } else if (status === 'canceled') {
            progressBar.style.width = '0%';
            progressBar.className = 'progress-bar canceled';
            statusText.textContent = 'Canceled';
        }
        else if (status === 'In progress') {
            progressBar.style.width = '50%';
            progressBar.className = 'progress-bar in-progress';
            statusText.textContent = 'In progress';
        }
    }
</script>










<!-- footer section starts  -->
<?php include 'components/footer.php'; ?>
<!-- footer section ends -->

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>