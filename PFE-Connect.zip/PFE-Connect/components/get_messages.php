<?php
// Database connection
$conn = new mysqli('localhost', 'username', 'password', 'course_db');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from GET request
$user1_id = $_GET['user1_id'];
$user2_id = $_GET['user2_id'];

// Fetch messages from database
$stmt = $conn->prepare("SELECT * FROM chat_messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY timestamp");
$stmt->bind_param("ssss", $user1_id, $user2_id, $user2_id, $user1_id);
$stmt->execute();
$result = $stmt->get_result();

// Output messages as JSON
$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}
echo json_encode($messages);

$stmt->close();
$conn->close();
?>