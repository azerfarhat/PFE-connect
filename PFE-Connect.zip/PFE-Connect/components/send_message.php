<?php
// Database connection
include '/connect.php';



// Get data from POST request
$sender_id = $_POST['sender_id'];
$receiver_id = $_POST['receiver_id'];
$message = $_POST['message'];

// Insert message into database
$stmt = $conn->prepare("INSERT INTO chat_messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $sender_id, $receiver_id, $message);
$stmt->execute();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chat</title>
    <script>
        function loadMessages() {
    const user1Id = document.getElementById('sender_id').value;
    const user2Id = document.getElementById('receiver_id').value;

    const xhr = new XMLHttpRequest();
    xhr.open('GET', `get_messages.php?user1_id=${user1Id}&user2_id=${user2Id}`, true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            const messages = JSON.parse(xhr.responseText);
            const chatBox = document.getElementById('chat_box');
            chatBox.innerHTML = '';
            messages.forEach(msg => {
                chatBox.innerHTML += `<p><strong>${msg.sender_id}:</strong> ${msg.message}</p>`;
            });
        }
    };
    setInterval(loadMessages, 5000); // Refresh every 5 seconds
    xhr.send();
}

        function sendMessage() {
            const senderId = document.getElementById('sender_id').value;
            const receiverId = document.getElementById('receiver_id').value;
            const message = document.getElementById('message').value;

            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'send_message.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onload = function () {
                if (xhr.status === 200) {
                    console.log('Message sent');
                    loadMessages();
                }
            };
            xhr.send(`sender_id=${senderId}&receiver_id=${receiverId}&message=${message}`);
        }

        function loadMessages() {
            const user1Id = document.getElementById('sender_id').value;
            const user2Id = document.getElementById('receiver_id').value;

            const xhr = new XMLHttpRequest();
            xhr.open('GET', `get_messages.php?user1_id=${user1Id}&user2_id=${user2Id}`, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    const messages = JSON.parse(xhr.responseText);
                    const chatBox = document.getElementById('chat_box');
                    chatBox.innerHTML = '';
                    messages.forEach(msg => {
                        chatBox.innerHTML += `<p><strong>${msg.sender_id}:</strong> ${msg.message}</p>`;
                    });
                }
            };
            xhr.send();
        }
    </script>
</head>

<body onload="loadMessages()">
    <!-- Your chat interface here -->
    <input type="text" id="sender_id" placeholder="Your ID">
    <input type="text" id="receiver_id" placeholder="Receiver ID">
    <textarea id="message" placeholder="Type your message"></textarea>
    <button onclick="sendMessage()">Send</button>
    <div id="chat_box"></div>
</body>
</html>