<?php

include '../components/connect.php';

if(isset($_COOKIE['tutor_id'])){
   $tutor_id = $_COOKIE['tutor_id'];
}else{
   $tutor_id = '';
   header('location:login.php');
}
$select_pfe = $conn->prepare("SELECT pfe.title AS pfe_name FROM `pfe` JOIN `encadrant` ON pfe.tutor_id = encadrant.id WHERE encadrant.id = ?");
$select_pfe->execute([$tutor_id]);

$show_pfe = $select_pfe->fetchAll(PDO::FETCH_ASSOC);


$select_contents = $conn->prepare("SELECT * FROM `content` WHERE tutor_id = ?");
$select_contents->execute([$tutor_id]);
$total_contents = $select_contents->rowCount();

$select_playlists = $conn->prepare("SELECT * FROM `pfe` WHERE tutor_id = ?");
$select_playlists->execute([$tutor_id]);
$total_playlists = $select_playlists->rowCount();

$select_likes = $conn->prepare("SELECT * FROM `likes` WHERE tutor_id = ?");
$select_likes->execute([$tutor_id]);
$total_likes = $select_likes->rowCount();

$select_comments = $conn->prepare("SELECT * FROM `comments` WHERE tutor_id = ?");
$select_comments->execute([$tutor_id]);
$total_comments = $select_comments->rowCount();

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Dashboard</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php'; ?>
   
<section class="dashboard">

   <h1 class="heading">dashboard</h1>

   <div class="box-container">
   <div class="box">
    <h3>PFEs</h3>
    <?php foreach ($show_pfe as $pfe): ?>
        <p><?= htmlspecialchars($pfe['pfe_name']); ?></p>  <!-- Display the name of each PFE -->
    <?php endforeach; ?>
</div>

      <div class="box">
         <h3>welcome!</h3>
         <p><?= $fetch_profile['name']; ?></p>
         <a href="profile.php" class="btn">view profile</a>
      </div>

      <div class="box">
         <h3><?= $total_contents; ?></h3>
         <p>total advice</p>
         <a href="add_content.php" class="btn">add new advices</a>
      </div>

      <div class="box">
         <h3><?= $total_playlists; ?></h3>
         <p>total PFEs</p>
         <a href="add_playlist.php" class="btn">add new PFE</a>
      </div>

      <div class="box">
         <h3><?= $total_likes; ?></h3>
         <p>total likes</p>
         <a href="contents.php" class="btn">view advices</a>
      </div>

      <div class="box">
         <h3><?= $total_comments; ?></h3>
         <p>total messages</p>
         <a href="comments.php" class="btn">view messages</a>
      </div>

      
      </div>

   </div>

</section>















<?php include '../components/footer.php'; ?>

<script src="../js/admin_script.js"></script>

</body>
</html>